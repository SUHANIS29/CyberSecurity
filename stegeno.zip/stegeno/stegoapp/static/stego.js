

let inputimg = document.querySelector("#enterfile");
let uploadimg = document.querySelector(".image-upload");

inputimg.onchange = function(){
    uploadimg.src = URL.createObjectURL(inputimg.files[0]);
}
let eyes = document.querySelector("#eye");
let passwdd = document.querySelector(".passwd-in");
let eyes2 = document.querySelector("#eyee");
let passwdd2 = document.querySelector(".passwd-inn");

eyes.addEventListener("click", ()=>{
    if(passwdd.type=='password'){
        passwdd.type = 'text';
        eyes.style.color = 'red';
    }
    else{
        passwdd.type = 'password';
        eyes.style.color = '#ff009e';
    }
});
let lab = document.querySelector("#enter")
let text = document.querySelector(".addText");
let paragh = document.querySelector(".hidetext");
let submit = document.querySelector(".sub");
let final;
let form = document.querySelector(".encrypt-form");
let newpass;
let str = [];
var load =  document.querySelector(".loader");

function ld(){
    if(load){
        console.log("loading....")
        setTimeout(()=>{
            load.style.display = 'none';
        },500);
    }
}
function lld(){
    console.log("loading 2");
    if (load){
        load.style.display = 'block';
    }

}



window.addEventListener("load",ld);
form.addEventListener('submit',lld);

