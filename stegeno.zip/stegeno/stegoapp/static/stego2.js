let eyes2 = document.querySelector("#eyee");
let passwdd2 = document.querySelector(".passwd-inn");
let outtext = document.querySelector(".outText");
let decrypt = document.querySelector(".sub2");
let text = document.querySelector("#ht");
let inputimg = document.querySelector("#enterfile");
let uploadimg = document.querySelector(".image-upload");
let form = document.querySelector(".decrypt-form");
var load =  document.querySelector(".loader");
function ld(){
    console.log("loading....");
    setTimeout(()=>{
        load.style.display = 'none';
    },500);
}

function lld(){
    console.log("loading 2");
    if (load){
        load.style.display = 'block';
    }

}

window.addEventListener("load",ld);
form.addEventListener("submit",lld);

inputimg.onchange = function(){
    uploadimg.src = URL.createObjectURL(inputimg.files[0]);
}
eyes2.addEventListener("click", ()=>{
    if(passwdd2.type=='password'){
        passwdd2.type = 'text';
        eyes2.style.color = 'red';
    }
    else{
        passwdd2.type = 'password';
        eyes2.style.color = '#ff009e';
    }
});



