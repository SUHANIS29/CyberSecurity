from PIL import Image

def encode_lsb(image_path, message, output_path):
    img = Image.open(image_path)
    binary_msg = ''.join([format(ord(i), '08b') for i in message + '#####'])
    pixels = img.load()
    idx = 0

    for y in range(img.height):
        for x in range(img.width):
            if idx < len(binary_msg):
                r, g, b = pixels[x, y]
                r = (r & ~1) | int(binary_msg[idx])
                pixels[x, y] = (r, g, b)
                idx += 1
    img.save(output_path)

def decode_lsb(image_path):
    img = Image.open(image_path)
    binary = ""
    pixels = img.load()

    for y in range(img.height):
        for x in range(img.width):
            r, g, b = pixels[x, y]
            binary += str(r & 1)

    chars = [chr(int(binary[i:i+8], 2)) for i in range(0, len(binary), 8)]
    message = ''
    for c in chars:
        message += c
        if message[-5:] == "#####":
            break
    return message[:-5]
