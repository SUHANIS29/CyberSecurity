from Crypto.Cipher import AES
from Crypto.Protocol.KDF import PBKDF2
from Crypto.Random import get_random_bytes
from Crypto.Util.Padding import pad
import base64

from Crypto.Util.Padding import unpad


from Crypto.Util.Padding import unpad

def encrypt_message(data, password):
    salt = get_random_bytes(16)
    key = PBKDF2(password, salt, dkLen=32, count=100000)
    cipher = AES.new(key, AES.MODE_CBC)
    ct_bytes = cipher.encrypt(pad(data.encode(), AES.block_size))

    return {
        'ciphertext': base64.b64encode(ct_bytes).decode(),
        'salt': base64.b64encode(salt).decode(),
        'iv': base64.b64encode(cipher.iv).decode()
    }


def decrypt_message(encrypted_data, password):
    try:
        ciphertext = base64.b64decode(encrypted_data['ciphertext'])
        salt = base64.b64decode(encrypted_data['salt'])
        iv = base64.b64decode(encrypted_data['iv'])

        key = PBKDF2(password, salt, dkLen=32, count=100000)
        cipher = AES.new(key, AES.MODE_CBC, iv)
        decrypted_padded = cipher.decrypt(ciphertext)
        decrypted = unpad(decrypted_padded, AES.block_size)
        return decrypted.decode()
    except Exception as e:
        print("Decryption error:", e)
        return None
