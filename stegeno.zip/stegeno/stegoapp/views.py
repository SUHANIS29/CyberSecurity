import io                                       # pip install pillow
from PIL import Image
from django.http import JsonResponse
from django.shortcuts import render
from .forms import EncodeForm, DecodeForm
from .stegofunctions import encode_lsb, decode_lsb
import os
import io
import json
from django.conf import settings
from .encyptted import encrypt_message, decrypt_message
from django.contrib import messages


def home_view(request):
    return render(request, 'home.html')



def encrypt_view(request):
    output_img = None

    if request.method == 'POST':
        form = EncodeForm(request.POST, request.FILES)
        if form.is_valid():
            img = form.cleaned_data['image']
            msg = form.cleaned_data['message']
            passwd = form.cleaned_data['password']
            
            # Encrypt message with password
            encrypted = encrypt_message(msg, passwd)
            json_data = json.dumps(encrypted)  # convert to JSON string

            filename = os.path.basename(img.name)
            input_path = os.path.join(settings.MEDIA_ROOT, filename)

            with open(input_path, 'wb+') as f:
                for chunk in img.chunks():
                    f.write(chunk)

            output_img_name = 'encoded_' + filename
            output_path = os.path.join(settings.MEDIA_ROOT, output_img_name)

            # Embed encrypted JSON string into image
            encode_lsb(input_path, json_data, output_path)
            output_img = output_img_name
    else:
        form = EncodeForm()

    return render(request, 'encrypt.html', {'form': form, 'output_img': output_img})

def decrypt_view(request):
    hidden_text = None
    decrypted_text = None

    if request.method == 'POST':
        form = DecodeForm(request.POST, request.FILES)
        if form.is_valid():
            imga = form.cleaned_data['image']
            passwd = form.cleaned_data['password']
            imgname = imga.name
            imgchunk = imga.chunks
            img = Image.open(imga)
            img = img.convert('RGBA')
            buffer = io.BytesIO()
            img.save(buffer,format='PNG')
            buffer.seek(0)
            img = Image.open(buffer)

            input_path = os.path.join(settings.MEDIA_ROOT, imgname)
            
            with open(input_path, 'wb+') as f:
                for chunk in imgchunk():
                    f.write(chunk)

            hidden_text = decode_lsb(input_path)

            try:
                encrypted_data = json.loads(hidden_text)  # expects JSON string from image
                print(encrypted_data)

                if not all(k in encrypted_data for k in ("ciphertext", "salt", "iv")):
                    decrypted_text = "Invalid embedded data format."
                else:
                    decrypted = decrypt_message(encrypted_data, passwd)
                    if decrypted is None:
                        messages.error(request , "wrong password")
                        decrypted_text = "No Message .."
                        
                    else:
                        messages.success(request , "correct password")
                        decrypted_text = decrypted

            except Exception as e:
                decrypted_text = f" Error during decryption: {str(e)}"
    else:
        form = DecodeForm()

    return render(request, 'decrypt.html', {
        'form': form,
        'hidden_text': hidden_text,
        'decrypted_text': decrypted_text
    })
