from django import forms

class EncodeForm(forms.Form):
    image = forms.ImageField(label='hello',widget=forms.ClearableFileInput(attrs={
            'id': 'enterfile',
            'accept':"image/jpeg,image/png,image/jpg"
            
            }))
    message = forms.CharField(widget=forms.Textarea(attrs={
        'class':"addText",
        'placeholder':'enter the text to hide'
    }
    )
    )
    password = forms.CharField(widget=forms.PasswordInput(attrs={
        'class' : "passwd-in",
        "placeholder":"password"
    }))

class DecodeForm(forms.Form):
    image = forms.ImageField(label='Upload Image for Decryption',widget=forms.ClearableFileInput(attrs={
            'id': 'enterfile',
            'accept':"image/jpeg,image/png,image/jpg"
            
            }))
    password = forms.CharField(widget=forms.PasswordInput(attrs={
        'class' : "passwd-inn",
        "placeholder":"password"
    }))
