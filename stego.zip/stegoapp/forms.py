from django import forms

class EncodeForm(forms.Form):
    image = forms.ImageField(label='Upload Image')
    message = forms.CharField(widget=forms.Textarea, label='Secret Message')

class DecodeForm(forms.Form):
    image = forms.ImageField(label='Upload Image for Decryption')
