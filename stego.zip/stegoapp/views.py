from django.shortcuts import render
from .forms import EncodeForm, DecodeForm
from .stegofunctions import encode_lsb, decode_lsb
import os
from django.conf import settings

def home_view(request):
    return render(request, 'home.html')

def encrypt_view(request):
    output_img = None
    if request.method == 'POST':
        form = EncodeForm(request.POST, request.FILES)
        if form.is_valid():
            img = form.cleaned_data['image']
            msg = form.cleaned_data['message']
            input_path = os.path.join(settings.MEDIA_ROOT, img.name)
            with open(input_path, 'wb+') as f:
                for chunk in img.chunks():
                    f.write(chunk)

            output_img_name = 'encoded_' + img.name
            output_path = os.path.join(settings.MEDIA_ROOT, output_img_name)
            encode_lsb(input_path, msg, output_path)
            output_img = output_img_name
    else:
        form = EncodeForm()
    return render(request, 'encrypt.html', {'form': form, 'output_img': output_img})

def decrypt_view(request):
    hidden_text = None
    if request.method == 'POST':
        form = DecodeForm(request.POST, request.FILES)
        if form.is_valid():
            img = form.cleaned_data['image']
            input_path = os.path.join(settings.MEDIA_ROOT, img.name)
            with open(input_path, 'wb+') as f:
                for chunk in img.chunks():
                    f.write(chunk)
            hidden_text = decode_lsb(input_path)
    else:
        form = DecodeForm()
    return render(request, 'decrypt.html', {'form': form, 'hidden_text': hidden_text})
